class BrowserImportError(Exception):
    """Error for cases when required libraries for browsers were not installed"""

    pass
